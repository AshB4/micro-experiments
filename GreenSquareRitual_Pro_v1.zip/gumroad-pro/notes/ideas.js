//asldjflaskjfa;
const ideas = ["", ""];// Sat May  3 15:47:20 CDT 2025
